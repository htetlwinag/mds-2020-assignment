package com.example.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.Project;

public interface ProjectRepository extends JpaRepository<Project, Long>{

    List<Project> findByIdIn(List<Long> idList);
   /* @Query (value = "Select p from Project  p where p.id in ?1")
    List<Project> findByIdInWithQuery(List<Long> idList);
    @Query (value = "select * from project where id in ?1",nativeQuery = true)
    List<Project> findByIdInWithNativeQuery(List<Long> idList);*/

}
