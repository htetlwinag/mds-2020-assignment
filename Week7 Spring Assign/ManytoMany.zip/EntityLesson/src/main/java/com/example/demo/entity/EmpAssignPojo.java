package com.example.demo.entity;

import java.util.List;

public class EmpAssignPojo {

	long employeeId;
	List<Long> projectList;
	public long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(long employeeId) {
		this.employeeId = employeeId;
	}
	public List<Long> getProjectList() {
		return projectList;
	}
	public void setProjectList(List<Long> projectList) {
		this.projectList = projectList;
	}
	
	
}
