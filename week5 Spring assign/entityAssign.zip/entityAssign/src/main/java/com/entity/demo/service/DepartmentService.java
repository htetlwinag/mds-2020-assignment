package com.entity.demo.service;


import java.util.List; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.demo.entity.Department;
import com.entity.demo.repo.DepartmentRepo;

@Service
public class DepartmentService {

	@Autowired
	DepartmentRepo departmentRepo;

	public List<Department> findAll() {
		return departmentRepo.findAll();
	}

	public Department addDepartment(Department department) {
		return departmentRepo.save(department);
	}

	
	
	
}
