package com.entity.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EntityAssignApplication {

	public static void main(String[] args) {
		SpringApplication.run(EntityAssignApplication.class, args);
	}

}
