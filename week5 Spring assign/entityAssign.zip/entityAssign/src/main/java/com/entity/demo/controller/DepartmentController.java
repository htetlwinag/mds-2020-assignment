package com.entity.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entity.demo.entity.Department;
import com.entity.demo.service.DepartmentService;

@RestController
public class DepartmentController {

	@Autowired
	DepartmentService departmentservice;
	
	@GetMapping (value = "/department")
	public List<Department> getDepartment() {
		return departmentservice.findAll();
	}
	@PostMapping (value = "/department")
	public Department addTeacher(@RequestBody Department department) {
		return departmentservice.addDepartment(department);
	}
}
