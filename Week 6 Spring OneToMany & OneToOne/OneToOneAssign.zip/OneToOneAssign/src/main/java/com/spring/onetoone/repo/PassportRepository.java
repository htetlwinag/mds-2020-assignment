package com.spring.onetoone.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.spring.onetoone.entity.Passport;
import com.spring.onetoone.entity.Student;
@Repository
public interface PassportRepository extends JpaRepository<Passport, Integer>{

	@Query("select s from Student s where id= :studentid")
	public Student getStudent(int studentid);
}
