package com.spring.onetoone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneToOneAssignApplicationTests {

	@Test
	void contextLoads() {
	}

}
