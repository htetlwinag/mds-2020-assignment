package com.example.demo.service;

import com.example.demo.entity.Phone;
import com.example.demo.repo.PhoneRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
public class PhoneService {

    @Autowired
    PhoneRepository phoneRepository;

    public Phone save(Phone phone){
        return phoneRepository.save(phone);
    }

    public Collection<Phone> saveAll(Collection<Phone> phones){
        return phoneRepository.saveAll(phones);
    }

}
