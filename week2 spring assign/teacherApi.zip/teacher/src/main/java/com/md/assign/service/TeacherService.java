package com.md.assign.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.md.assign.Entity.Teacher;
import com.md.assign.repository.TeacherRepository;

@Service
public class TeacherService {

	@Autowired
	TeacherRepository teacherRepository;
	
	public List<Teacher> findAll(){
		return teacherRepository.findAll();
	}
	
	public Teacher addTeacher(Teacher teacher) {
		return teacherRepository.save(teacher);
	}
	public Teacher findById(Long id) {
		// TODO Auto-generated method stub
		return  teacherRepository.findById(id).orElse(null);
	}
	public void deleteTeacher(Long id) {
		teacherRepository.deleteById(id);
	}
}
