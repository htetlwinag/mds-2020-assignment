package pub1ic;

public class Number {

	 public static void main(String args[]){
		 Add obj = new Add();
	      System.out.println(obj.addTwoNumbers(100, 1));
	   }
}
