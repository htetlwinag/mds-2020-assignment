package pub1ic;

public class Add {

	public int addTwoNumbers(int a, int b){
		return a+b;
	   }
}
