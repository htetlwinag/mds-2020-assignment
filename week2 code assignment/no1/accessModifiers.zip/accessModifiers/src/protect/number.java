package protect;



public class number {

	 public static void main(String args[]){
		 add obj = new add();
			System.out.println(obj.addTwoNumbers(11, 22));
		   } 
}
