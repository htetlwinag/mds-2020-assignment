package protect;

public class add {

	protected int addTwoNumbers(int a, int b){
		return a+b;
	   }
}
