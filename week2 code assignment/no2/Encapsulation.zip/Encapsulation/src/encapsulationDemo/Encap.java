package encapsulationDemo;

public class Encap {

	public static void main(String args[]){
        EncapsulationDemo obj = new EncapsulationDemo();
        obj.setName("htet lwin aung");
        obj.setDob("16.6.2004");
        obj.setSalary(800000);
        System.out.println(" Name: " + obj.getName());
        System.out.println(" Salary: " + obj.getSalary());
        System.out.println(" Age: " + obj.getDob());
   } 
}
