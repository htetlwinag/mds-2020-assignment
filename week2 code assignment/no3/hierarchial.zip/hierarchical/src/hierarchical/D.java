package hierarchical;

public class D extends A{

	public void methodD()
	{
	   System.out.println("method of Class D");
	}
}
