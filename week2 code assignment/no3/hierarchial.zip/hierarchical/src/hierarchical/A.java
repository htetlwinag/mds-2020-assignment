package hierarchical;

public class A {

	public void methodA()
	{
	   System.out.println("method of Class A");
	}
	
}

//public void methodA()
//{
   //System.out.println("method of Class A");
//}