package hierarchical;

public class C extends A{

	public void methodC()
	{
	   System.out.println("method of Class C");
	}
}
