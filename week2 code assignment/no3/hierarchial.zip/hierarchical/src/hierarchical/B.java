package hierarchical;

public class B extends A {

	public void methodB()
	{
	   System.out.println("method of Class B");
	}
}
