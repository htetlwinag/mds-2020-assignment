package mInheritance;

public class C extends B{

	public C()
	   {
		System.out.println("Speed");
	   }
	   public void speed()
	   {
		System.out.println("Max: 80Kmph");
	   }
}
