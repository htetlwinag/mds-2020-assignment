package mInheritance;

public class mInheritance {

	 public static void main(String args[])
	   {
		C obj=new C();
		 obj.Brand();
		 obj.brand();
		 obj.speed();
		
	   }
}
