package mInheritance;

public class B extends A{

	 public B()
	   {
		System.out.println("Car");
	   }
	   public void brand()
	   {
		System.out.println("Brand: BMW");
	   }
	   
}
