package mInheritance;

public class A {

	 public A()
	   {
		System.out.println("Circle");
	   }
	   public void Brand()
	   {
		System.out.println(" Brand: CBR");
	   }
}
