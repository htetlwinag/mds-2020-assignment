package inheritance;

public class Teacher {

	String name = "Daw Mya";
	   String subject = "algorithm";
	   
	}

	
