package inheritance;

public class pTeacher extends Teacher{

		 
		   public static void main(String args[]){
			   pTeacher obj = new pTeacher();
			System.out.println(obj.subject);
			System.out.println(obj.name);
			
		   }
	}

