package polymorphism;

public class Aminal {

	public void sound(){
	      System.out.println("Animal Sound");   
	   }
}
