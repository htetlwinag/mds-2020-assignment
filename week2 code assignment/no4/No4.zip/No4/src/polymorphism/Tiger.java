package polymorphism;

public class Tiger extends Aminal{

	@Override
    public void sound(){
        System.out.println("Nyaung");
    }
}
