package polymorphism;

public class Main {

	public static void main(String args[]){
    	Aminal horse = new Horse();
    	Aminal tiger = new Tiger();
    	horse.sound();
    	tiger.sound();
    }
}
