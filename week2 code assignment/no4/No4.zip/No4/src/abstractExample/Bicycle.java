package abstractExample;

abstract public class Bicycle{

	public void speed(){
	      System.out.println("200kmph");
	   }
}
