package abstractExample;

 public class Airplane extends Car{

	public void speed(){
	      System.out.println("300kmph");
	   }
}
