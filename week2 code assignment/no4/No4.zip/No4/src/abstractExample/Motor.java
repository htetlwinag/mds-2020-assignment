package abstractExample;

public class Motor {

	public void speed(){
	      System.out.println("200kmph");
	   }
}
