package abstractExample;

abstract public class Car extends Motor{

	public void speed(){
	      System.out.println("180kmph");
	   }
}
