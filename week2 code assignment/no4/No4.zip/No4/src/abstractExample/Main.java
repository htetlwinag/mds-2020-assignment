package abstractExample;

public class Main {

	 public static void main(String args[]){
	     Airplane airplane=new Airplane();
	     airplane.speed();
	   }
}
