package Aggregation;

import java.util.List;


public class Course {

	public  int id;
	public  String name;
	public  String code;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	 class Semester {

	    public String summer;
	    public String winter;
	    private List<Course> courses;
	    
		public String getSummer() {
			return summer;
		}
		public void setSummer(String summer) {
			this.summer = summer;
		}
		public String getWinter() {
			return winter;
		}
		public void setWinter(String winter) {
			this.winter = winter;
		}
		public List<Course> getCourses() {
			return courses;
		}
		public void setCourses(List<Course> courses) {
			this.courses = courses;
		} 
		public List<Course> getCourse()  
	    { 
	        return courses; 
	    } 

	    }
	 public class Department {
			public  String name;
			public  String number;
		    private List<Course> courses;
		    
			public String getName() {
				return name;
			}
			public void setName(String name) {
				this.name = name;
			}
			public String getNumber() {
				return number;
			}
			public void setNumber(String number) {
				this.number = number;
			}
			public List<Course> getCourses() {
				return courses;
			}
			public void setCourses(List<Course> courses) {
				this.courses = courses;
			}
			public List<Course> getCourse()  
		    { 
		        return courses; 
		    } 

		}
	 public static void main (String[] args){
		 
	 }
}
