package Composition;

import java.util.List;

public class Semester {

	public String summer;
	public String winter;
	public String getSummer() {
		return summer;
	}
	public void setSummer(String summer) {
		this.summer = summer;
	}
	public String getWinter() {
		return winter;
	}
	public void setWinter(String winter) {
		this.winter = winter;
	}

	public class RegisterationForm {
		private List<Semester> semester;
		
		RegisterationForm (List<Semester> books) 
	    { 
	        this.semester = semester;  
	    } 
	      
	    public List<Semester> getTotalBooksInLibrary(){ 
	          
	       return semester;   
	    } 
	}

	public static void main (String[] args){
		 
	 }
}
