package Composition;

import java.util.List;

public class Course {

		public  int id;
		public  String name;
		public  String code;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getCode() {
			return code;
		}
		public void setCode(String code) {
			this.code = code;
		}
		
		public class RegisterationForm {
			private List<Course> course;
			
			RegisterationForm (List<Course> books) 
		    { 
		        this.course = course;  
		    } 
		      
		    public List<Course> getTotalBooksInLibrary(){ 
		          
		       return course;   
		    } 
		}
		 public static void main (String[] args){
			 
		 }
}
