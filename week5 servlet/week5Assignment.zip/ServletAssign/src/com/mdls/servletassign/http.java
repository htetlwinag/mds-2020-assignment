package com.mdls.servletassign;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Post")
public class http extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException  {
		res.getWriter().println("<h6>Welcome to my world</h6>");
			    
			}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		response.setContentType("text/html");
		String username=request.getParameter("username");
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		String con_password=request.getParameter("con_password");
		pw.println("username ="+username);
		pw.print("email ="+email);
		pw.println("password ="+password);
		pw.println("con_password ="+con_password);
	}
	
}
